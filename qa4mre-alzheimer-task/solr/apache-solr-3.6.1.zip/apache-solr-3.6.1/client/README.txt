For a list of many Solr client libraries, see 
http://wiki.apache.org/solr/IntegratingSolr
